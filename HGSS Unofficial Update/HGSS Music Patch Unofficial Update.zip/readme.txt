Since no one is updating this anymore, I might as well do that. -LukeeGD

Here's HGSS Music Patch "Unofficial" Update
- This fixes the major bugs of the existing patch, including the music freezing/beeping bug
- Includes ipatix's music mixer, it makes the music have less noise
- Available for FireRed and Emerald

Patching is similar to my B2W2 Music Patch:
Extending the ROM is REQUIRED, do this before proceeding. XSE is what I use to do this.
1. Apply the .ips patch to your ROM (Use the correct one!)
2. Open the file "HGSS Unofficial Update.bit" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there.
6. Save!
Steps 7 to 10 are for FireRed only:
7. Open "Songtable.bit" and your FireRed ROM in HxD.
3. Select all of the contents (Ctrl+A) of Songtable.bit and copy it (Ctrl+C).
9. Go to (Ctrl+G) 1000000 and paste-write (Ctrl+B) the copied content there.
10. Save!

Song list is similar to OP but with a few differences.
For FireRed: Some songs are added and/or swapped.
For Emerald: It's exactly the same as the one in OP.

An updated sappy.xml is also included in the zip file (to be used for FireRed)

Credits to all the creators of HGSS Music Patch:
GoGoJJTech, ipatix, Wobbu